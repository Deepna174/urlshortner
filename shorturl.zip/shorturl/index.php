<?php
require_once('header.php');
require('config.php');
?>
<html>
    <style>

        .wrap{
            word-wrap: break-word;
        }
    </style>
    <body>

        <div class="row">
            <center>
                <h3>WELCOME</h3>
                <p>Used to create a short url of a big url </p>
                <p>
                    <b>Url</b>: 
                <div class="wrap"> <p > Enter the complete url inside the text field click on the button 'Get Shorten'<br>
                        If the url exist in the database show the shorten url else a random short code will generate and insert for the link. 
                        <br>By using the shorten url you can access the actual url</p></div>
                <b>Add</b>:
                <div class="wrap"> <p > Insert url and its shortcode to the database by entering the short code or generating a random string by clicking on the random icon 
                        <br>the save it.

                    </p>

                </div>
            </center>
        </div>

    </body>

    <?php
// To Redirect the shortcode to Orginal 
    if ((isset($_GET['rt'])) && ($_GET['rt'] != '')) {
        $code = $_GET['rt'];
        $query = "SELECT * FROM `shroten_url` WHERE `short_code` = '" . $code . "' ORDER BY id DESC limit 1 ";
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $url = $row['url'];
            $query = "update `shroten_url` set visit=visit+1 WHERE `id` = " . $row['id'];
            $result = $conn->query($query);
            header("location:" . $url);
        } else {
            header("location:short.php");
        }
        unset($_GET['rt']);
    }

    require_once('footer.php');
    ?>
</html>