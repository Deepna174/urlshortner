<div class="row">
    <center>
        <footer>
            <p>Developed by Deepna</p>
        </footer>
    </center>
</div>