<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">



        <style>
            /* Style the body */
            body {
                font-family: Arial;
                margin: 0;
            }

            /* Header/Logo Title */
            .header {
                height:150px ;
                padding: 60px;
                text-align: center;
                background: #1abc9c;
                font-size: 20px;
                color: #fff;
            }
            .menu{
                padding: 50px
            }

            footer{
                position: absolute;
                bottom: 0;
                left: 0;
                right: 0;
                background: #1abc9c;
                height: auto;
                width: 100vw;
                padding-top: 40px;
                color: #fff;
            }
        </style>
    </head> 
</html>

<div class="header">
    <h2>Shorten Url</h2>
    <div class="header-right">
        <a class="active menu" href="index.php"><i class="fa fa-home" aria-hidden="true"></i>
</a>
        <a class="menu" href="short.php">Url</a>
        <a class="menu" href="add.php">Add</a>
    </div>
</div>