<?php require_once('header.php');
?>
<html>
    <body>
        <div class="row">
            <center>
                <h3>Shorten Url</h3>
                <form method="POST" id='shorten_url'>
                    <p><input type="url" id="big_url" style="width:500px" name="big_url" placeholder="Enter complete url" class="form-control required" /></p>
                    <p><input class='btn success' type="submit" id="submit" name="add" value="Get Shorten" /></p>
                </form>
                
                <div id="sorten" style="display:'none'">
                        <p> Shorten url is given below
                        <br/>
                        <div id='redirect'>
                            
                            
                            
                        </div>
                </p>

                    </div>

            </center>
        </div>

    </body>
    <script type="text/javascript">
 $(function() {
	$("#shorten_url").on("submit", function(event) {
		event.preventDefault();
		var form = $(this);
		$.ajax({
			url: "shorturl.php?url=search",
			type: "POST",
			data: form.serialize(),
			success: function(data) {
				if ((data != 0)&&(data != 2)) {
					document.getElementById("sorten").style.display = "block";
					$('#redirect').html(data);
				}else if(data == 2){
                                        alert("Please Enter a url");
                                        $('#redirect').html('');
                                }else {
					alert("No shorten url Found");
					$('#redirect').html('');
				}
			}
		});
	});

})
   

    </script> 
    <?php require_once('footer.php');
    ?>
</html>