<?php

require('config.php');

//To check the shorcode is already exist or not in the db

if ((isset($_GET['exist'])) && ($_GET['exist'] != '')) {
    $code = $_GET['exist'];
    $query = "SELECT * FROM `shroten_url` WHERE `short_code` = '" . $code . "' ";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        echo 0;
    } else {
        echo 1;
    }
    unset($_GET['exist']);
}


// To get random shortcode 

if ((isset($_GET['random'])) && ($_GET['random'] == 1)) {
    $string = create_random();
    echo $string;
    unset($_GET['random']);
}


//To insert url and its short code to the db.If the url is already exists in db then update new short code for that url

if ((isset($_GET['add'])) && ($_GET['add'] == 'insert')) {

    //Post data
    $url = $_POST['big_url'];
    $code = $_POST['short_code'];
    if (($url != '') && ($code != '') && filter_var($url, FILTER_VALIDATE_URL)) {
        $query = "SELECT * FROM `shroten_url` WHERE `url` = '" . $url . "' ORDER BY id DESC limit 1 ";  //Checking already inserted or not
        $result_check = $conn->query($query);
        if ($result_check->num_rows <= 0) {
            $query = "INSERT INTO shroten_url (url, short_code)VALUES ('" . $url . "','" . $code . "')";
            $result = $conn->query($query);
            if ($conn->insert_id) {
                echo 1;
            } else {
                echo 0;
            }
        } else {
            $row = $result_check->fetch_assoc();
            $id = $row['id'];
            $update_query = "Update shroten_url set short_code='" . $code . "' where id='" . $id . "'";
            $result = $conn->query($update_query);
            echo 1;
        }
    } else {
        echo 0;
    }
    unset($_GET['add']);
}


// To Get the shorten url 

if ((isset($_GET['url'])) && ($_GET['url'] != '')) {
    $url = $_POST['big_url'];
    if ($url != '') {
        $query = "SELECT * FROM `shroten_url` WHERE `url` = '" . $url . "' ORDER BY id DESC limit 1 ";
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $code = $row['short_code'];
            $url_build = $base_url.$code;
            echo '<a href="' . $url_build . '">' . $url_build . '</a>';
        } else {
            $short_code = create_random();
            $query = "INSERT INTO shroten_url (url, short_code)VALUES ('" . $url . "','" . $short_code . "')";
            $result = $conn->query($query);
            if ($conn->insert_id) {
                $url_build = $base_url.$short_code;
                echo '<a href="' . $url_build . '">' . $url_build . '</a>';
            } else {
                echo 0;
            }
        }
    } else {
        echo 2;
    }
    unset($_GET['url']);
}

// Fuction to generate random short code
function create_random() {
    $exp = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $length = strlen($exp);
    $shortcode = '';
    for ($i = 0; $i < 8; $i++) {
        $shortcode .= $exp[rand(0, $length - 1)];
    }
    return $shortcode;
}

?>