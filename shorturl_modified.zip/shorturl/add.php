<?php require_once('header.php');
?>
<html>
    <body>
        <div class="row">
            <center>
                <h3> Add </h3>
                <form method="POST" id='shorten_url'>
                    <p><input type="url" id="big_url" style="width:500px" name="big_url" placeholder="complete url" class="form-control required" /></p>

                    <p><input type="text" id="short_code" style="width:450px" placeholder="shortcode" name="short_code" class="required" onChange="check_existance(this.value);"/><button type='button' style="font-size:24px;width:50px" onClick="generate_random()" title="Random short code"><i class="fa fa-random"></i></button></p>

                    <p><input class='btn success' type="submit" id="submit" name="add" value="Save" /></p>
                </form>
            </center>
        </div>

    </body>
    <script type="text/javascript">

        $(function() {
 	$("#shorten_url").on("submit", function(event) {
 		event.preventDefault();
 		var form = $(this);
 		$.ajax({
 			url: "shorturl.php?add=insert",
 			type: "POST",
 			data: form.serialize(),
 			success: function(data) {
 				if (data == 1) {
 					alert("Data added/updated succesfully");
 					location.href = 'short.php';
 				} else {
 					alert("Error on adding record");
 				}
 			}
 		});
 	});

 })

 function check_existance(short) {
 	$.ajax({
 		url: "shorturl.php?exist=" + short,
 		type: "POST",
 		success: function(data) {
 			if (data == 0) {
 				alert("Sorry shortcode already taken");
 				$('#short_code').val("");
 			}
 		}
 	});



 }

 function generate_random() {
 	$.ajax({
 		url: "shorturl.php?random=1",
 		type: "POST",
 		success: function(data) {
 			if (data != 0) {
 				$('#short_code').val(data);
 			}
 		}
 	});



 }
    </script> 
    <?php require_once('footer.php');
    ?>
</html>